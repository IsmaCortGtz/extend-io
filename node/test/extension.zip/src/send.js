async function send(message) {
  await new Promise(resolve => resolve());
  return message;
}